const evenOddNegative = (number) => {
  if (number % 2 === 0) return 0.5;
  else return -0.5;
};

const getAngle = (dx, dy) => {
  return (Math.atan(dy / dx) * 180) / Math.PI;
};
const getDistance = (dx, dy) => {
  console.log("distancia", Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2)));
  return Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
};
const getQuadrant = (x1, y1, x2, y2) => {
  let angle = getAngle(x2 - x1, y2 - y1);
  console.log(x1, x2, y1, y2);
  if (angle >= 0 && x2 > x1 && y2 > y1) {
    console.log(2);
    return 2;
  }
  if (angle >= 0 && x2 < x1 && y2 < y1) {
    console.log(4);
    return 4;
  }
};

export const getLinePoints = (x1, y1, x2, y2, n) => {
  // console.log(x1, y1, x2, y2);
  //se getAngle > 0 quadrantes 2 e 4
  //se getAngle <0 quadrantes 1 e 3
  console.log(getAngle(x2 - x1, y2 - y1) + 15);
  getQuadrant(x1, y1, x2, y2);
  let midX = 0;
  let midY = 0;
  if (getQuadrant(x1, y1, x2, y2) === 2) {
    midX =
      x1 +
      (Math.cos((getAngle(x2 - x1, y2 - y1) + 5 * n * Math.PI) / 180) *
        getDistance(x2 - x1, y2 - y1)) /
        2;

    midY =
      y1 +
      (Math.sin((getAngle(x2 - x1, y2 - y1) + 5 * n * Math.PI) / 180) *
        getDistance(x2 - x1, y2 - y1)) /
        2;
  } else if (getQuadrant(x1, y1, x2, y2) === 4) {
    midX =
      x2 +
      (Math.cos((getAngle(x1 - x2, y1 - y2) + 5 * n * Math.PI) / 180) *
        getDistance(x2 - x1, y2 - y1)) /
        2;

    midY =
      y2 +
      (Math.sin((getAngle(x1 - x2, y1 - y2) + 5 * n * Math.PI) / 180) *
        getDistance(x2 - x1, y2 - y1)) /
        2;
  }

  let points =
    n === 1
      ? [x1, y1, x2, y2]
      : [
          x1,
          y1,
          // (x2 + y2) / 2 - 10 * n * evenOddNegative(n),
          // (x1 + y1) / 2 - 10 * n * evenOddNegative(n),
          // (y1 + y2) / 2 - 10 * n * evenOddNegative(n),
          // (x1 + x2) / 2 - 10 * n * evenOddNegative(n),

          // (x1 + y1) / 2 + 1 * n * evenOddNegative(n),
          // (x2 + y2) / 2 + 1 * n * evenOddNegative(n),
          // (x2 + y2) / 2 + 1 * n * evenOddNegative(n),
          // (x1 + y1) / 2 + 1 * n * evenOddNegative(n),

          // x1 + 1 * n * evenOddNegative(n),
          // y1 + 1 * n * evenOddNegative(n),
          // x2 + 1 * n * evenOddNegative(n),
          // y2 + 1 * n * evenOddNegative(n),
          midX,
          midY,
          midX,
          midY,

          // (x1 + x2) / 2 + 20 * n * evenOddNegative(n),
          // (y1 + y2) / 2 + 20 * n * evenOddNegative(n),
          // (y1 + y2) / 2 - 10 * n * evenOddNegative(n),
          // (x1 + x2) / 2 - 10 * n * evenOddNegative(n),

          x2,
          y2,
        ];
  return points;
};
