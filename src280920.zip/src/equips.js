export const _EQUIPS = [
  {
    type: "UG",
    name: "UG1_A",
    endPointA: "A",
    volt_base: 500,
    color: "#00F",
  },
  {
    type: "LT",
    endPointA: "A",
    endPointB: "B",
    volt_base: 500,
    color: "#00F",
  },
  {
    type: "LT",
    endPointA: "A",
    endPointB: "B",
    volt_base: 500,
    color: "#00F",
  },
  {
    type: "LT",
    endPointA: "A",
    endPointB: "B",
    volt_base: 500,
    color: "#00F",
  },
  {
    type: "LT",
    endPointA: "A",
    endPointB: "B",
    volt_base: 500,
    color: "#00F",
  },
  {
    type: "LT",
    endPointA: "A",
    endPointB: "B",
    volt_base: 500,
    color: "#00F",
  },
];
