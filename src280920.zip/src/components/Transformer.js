import React from "react";
import { Circle, Group } from "react-konva";
import { _SETTINGS } from "../settings";
const Transformer = ({ x, y, index, handleDrag }) => {
  const radius = _SETTINGS.TR.radius || _SETTINGS.default.radius;
  const stroke = _SETTINGS.TR.stroke || _SETTINGS.default.stroke;
  const strokeWidth = _SETTINGS.TR.strokeWidth || _SETTINGS.default.strokeWidth;
  const draggable = _SETTINGS.TR.draggable || _SETTINGS.default.draggable;

  // console.log(props.handleDrag);
  return (
    <Group
      draggable={draggable}
      x={x}
      y={y}
      index={index}
      onDragMove={(e) => handleDrag(e)}
    >
      {/* HIGH SIDE */}
      <Circle
        x={-radius + radius / 4}
        y={radius / 4}
        radius={radius}
        stroke={stroke}
        strokeWidth={strokeWidth}

        // fill={"#FFF"}
      />
      {/* LOW SIDE */}
      <Circle
        x={radius - radius / 4}
        y={radius / 4}
        radius={radius}
        stroke={stroke}
        strokeWidth={strokeWidth}
        // fill={"#FFF"}
      />
      {/* TERTIARY SIDE */}
      <Circle
        y={-radius + radius / 4}
        radius={radius}
        stroke={stroke}
        strokeWidth={strokeWidth}
        // fill={"#FFF"}
      />
    </Group>
  );
};

export default Transformer;
